package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;

@Controller
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    // Display all students
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("students", service.getAllStudents());
        model.addAttribute("totalStudents",service.getTotalStudents());
        model.addAttribute("totalCourses", 5);
        return "index";
    }
    // Open Add Student Page
    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("student", new Student());
        return "add-student";
    }

    // Save Student
    @PostMapping("/save")
    public String saveStudent(Student student) {

        System.out.println("Student Name: " + student.getName());
        System.out.println("Email: " + student.getEmail());
        System.out.println("Course: " + student.getCourse());

        service.saveStudent(student);

        return "redirect:/";
    }

    // Open Edit Student Page
    @GetMapping("/edit/{id}")
    public String editStudent(@PathVariable Long id, Model model) {

        Student student = service.getStudentById(id);

        model.addAttribute("student", student);

        return "edit-student";
    }

    // Update Student
    @PostMapping("/update")
    public String updateStudent(Student student) {

        service.saveStudent(student);

        return "redirect:/";
    }

    // Delete Student
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {

        service.deleteStudent(id);

        return "redirect:/";
    }
}